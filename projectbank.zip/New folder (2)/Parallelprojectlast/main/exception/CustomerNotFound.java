package exception;

public class CustomerNotFound extends Exception
{


}
