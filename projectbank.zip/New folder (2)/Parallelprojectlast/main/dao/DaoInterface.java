package dao;

import java.util.HashMap;

import bean.Customer;

public interface DaoInterface {
	public long createAccount(long accno,Customer c);
	public Customer displayAccount(long accno);
	//public HashMap<Long,Customer> getAll();
	public Customer showBalance(long accno,int pin);
	public Customer deposit(float depositamt,long accno,int pin);
	public Customer withdraw(float withdrawamt,long accno,int pin);
	public Customer fundTransfer(long accno,int pin,long taccno,float transferamt);
	public Customer printTransactions(Customer c);
	
	

}
