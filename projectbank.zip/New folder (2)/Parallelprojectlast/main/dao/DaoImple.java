package dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import bean.Customer;

public class DaoImple implements DaoInterface {
	HashMap<Long, Customer> customermap = new HashMap<Long,Customer>();
	Map<Long, StringBuffer> transaction = new HashMap<Long, StringBuffer>();
	

	@Override
	public long createAccount(long accno,Customer c) {
		// TODO Auto-generated method stub
		 customermap.put(accno,c);
		 System.out.println(customermap);
	
	if(customermap.isEmpty()) {
		System.out.println("ACCOUNT IS NOT CREATED!!!!");
	}
	else {
		System.out.println("ACCOUNT IS SUCCESFULLY CREATED!!!!");
	}
	  
	    
		
	return accno;	
	}




	public Customer displayAccount(long accno) {
		// TODO Auto-generated method stub
		Customer cust=null;
		System.out.println("THE DETAILS OF THE CUSTOMER"+customermap);
		
		for(Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				System.out.println("The account details are"+customermap);
	
			
				
			}
		
			
		}
		return cust;
			
		}
	/*public HashMap<Long,Customer> getAll(){
		System.out.println("in get all "+customermap);
		return customermap;
	}*/



	@Override
	public Customer showBalance(long accno, int pin) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer customermap:customermap.values()) {
			if(customermap.getAccno()==accno) {
				if(customermap.getPin()==pin) {
					System.out.println("The balance present in the account"+ "  "+ customermap.accno +"  "+ customermap.balance);
					customermap.setBalance(accno);
				}
			}
		}
		return cust;
	}



	@Override
	public Customer deposit(float depositamt, long accno, int pin) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for(Customer customermap3:customermap.values()) {
			if(customermap3.getAccno()==accno) {
				
				if(customermap3.getPin()==pin) {
					
					
						System.out.println("The amount present in your account before depositing is:"+ customermap3.balance);
						float amt=customermap3.getBalance();
						amt=amt+depositamt;
						System.out.println("The amount present in your account after the deposit is"+ amt);
						customermap3.setBalance(amt);
						cust=customermap3;
					}
				}
			}
		
		return cust;
	}



	@Override
	public Customer withdraw(float withdrawamt, long accno, int pin) 
	{
		// TODO Auto-generated method stub
		Customer cust=null;
		for(Customer customermap4:customermap.values()) 
		{
			if(customermap4.getAccno()==accno) 
			{
				
				if(customermap4.getPin()==pin) 
				{
					
						System.out.println("The amount present in your account is"+customermap4.balance);
						float amt=customermap4.getBalance();
						amt=amt-withdrawamt;
						System.out.println("The amount present in your account after the withdrawl is:"+ amt);
						customermap4.setBalance(amt);
					cust=customermap4;
				}
			}
		}
		return cust;
	}
	

	@Override
	public Customer fundTransfer(long accno, int pin,  long taccno, float transferamt) 
	{
		System.out.println("1111");
		Customer cust=null;
		for(Customer customermap1:customermap.values()) 
		{
			System.out.println(customermap1);
			System.out.println(accno);
			System.out.println(pin);
			System.out.println("22222222");
			if(customermap1.getAccno()==accno && customermap1.getPin()==pin) 
			{
				System.out.println("333333");
				float amt = customermap1.getBalance();
				if(transferamt < amt)
				{
					System.out.println("4444");
					float amt1= customermap1.getBalance();
					amt1= amt1-transferamt;
					customermap1.setBalance(amt1);
					System.out.println("the balance present in your account after transferring is"+amt1);
					for(Customer customermap5 : customermap.values())
					{
						System.out.println("55555");
					//if(customermap.containsKey(transferamt) && customermap.containsKey(taccno))
						if(customermap.containsKey(taccno))
						{
							System.out.println("66666");
						float amt2= customermap5.getBalance();
						amt2 = amt2 + transferamt;
						customermap5.setBalance(amt2);
						customermap1.setBalance(amt1);
						//customermap1.setBalance(amt1);
						cust = customermap5;
						//System.out.println("the balance present in your account after transferring is"+amt1);
						System.out.println("the balance present in your account after transferring is"+amt2);
						}
					}
				}
		

			}
		
		
	}
		return cust;
}




	public Customer printTransactions(Customer c) {
		// TODO Auto-generated method stub
		Customer cust = null;
		long a = c.getAccno();
		StringBuffer s = new StringBuffer();
		s = c.getSb();
		s.append("balance is now ");
		s.append(c.getBalance());
		c.setSb(s);
		transaction.put(a, s);
		System.out.println("inside print transaction");
		for(StringBuffer transaction1 : transaction.values())
		{
			
			transaction.entrySet().stream().forEach(System.out::println);
			System.out.println("aaaaaaa");
			System.out.println(transaction);
		}
		return cust;
		
	}
}