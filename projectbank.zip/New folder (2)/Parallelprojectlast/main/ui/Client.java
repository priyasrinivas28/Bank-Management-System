package ui;

import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import bean.Customer;
import dao.DaoImple;
import exception.CustomerNotFound;
import service.ServiceImpl;
import service.ServiceInterface;

public class Client {
	static ServiceInterface ib=null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServiceImpl serviceobj= new ServiceImpl();
		Random rand = new Random();
		
		ib=new ServiceImpl();
		while(true){
			
		System.out.println("WELCOME TO custobjobjOMER MANAGEMENT SYSTEM");
		System.out.println("1.CREATE ACCOUNT");
		System.out.println("2.DISPLAY ACCOUNT DETAILS");
		System.out.println("3.SHOW BALANCE");
		System.out.println("4.DEPOSIT");
		System.out.println("5.WITHDRAW");
		System.out.println("6.FUND TRANSFER");
		System.out.println("7.PRINT TRANSACTION");
		System.out.println("8.EXIT");
		
		System.out.println("ENTER YOUR CHOICE");
Scanner sc= new Scanner(System.in);
int ch=sc.nextInt();

switch(ch){
case 1:
System.out.println("WELCOME TO BANK MANAGEMENT SYSTEM");
Customer custobj=new Customer();
	
	do {
	System.out.println("ENTER YOUR FIRSTNAME");
	String firstname= sc.next();
	custobj.setFirstname(firstname);
	}while(!serviceobj.validateName(custobj.firstname));
	
	
	System.out.println("ENTER YOUR MIDDLENAME");
	String middlename= sc.next();
	custobj.setMiddlename(middlename);
	
	System.out.println("ENTER YOUR LASTNAME");
	String lastname= sc.next();
	custobj.setLastname(lastname);

	do {
	System.out.println("ENTER YOUR age");
	int age=sc.nextInt();
	custobj.setAge(age);
	}while(!serviceobj.validateAge(custobj));
	
	do {
	System.out.println("ENTER YOUR PHONE NUMBER");
	long phoneno =sc.nextLong();
	custobj.setPhoneno(phoneno);
	}while(!serviceobj.validatePhonenumber(custobj.phoneno));
	
	do {
	System.out.println("ENTER YOUR ADDRESS");
	String address =sc.next();
	custobj.setAddress(address);
	}while(!serviceobj.validateAddress(custobj.address));
	
	do {
	System.out.println("ENTER THE BALANCE");
	float balance =sc.nextFloat();
	custobj.setBalance(balance);
	}while(!serviceobj.validateBalance(custobj));
	
	long accno = 100000 + rand.nextInt(1000000); 
	System.out.println("YOUR ACCOUNT NUMBER FOR THE "+custobj.getFirstname()+custobj.getMiddlename()+custobj.getLastname()+"IS"+accno);
	custobj.setAccno(accno);
	int pin = 1000 + rand.nextInt(90000);
	System.out.println("YOUR PIN FOR THE ACCOUNT NUMBER "+accno+ "IS" + pin);

custobj.setPin(pin);
	
	serviceobj.createAccount(accno, custobj);



	
	

	
	
	

break;

case 2:
	System.out.println("enter the account number");
	long accno1=sc.nextLong();
	Customer custobj1=new Customer();
Customer c= serviceobj.displayAccount(custobj1.getAccno());

	break;
	
	/*System.out.println("in 2");
	HashMap<Long,Customer> ll=ib.getAll();
	ll.values().stream().forEach(System.out::println);
			*/

		case 3:
			Customer custobj2=new Customer();
			System.out.println("enter accno to get the record");
	long accno2=sc.nextLong();
	System.out.println("enter the pin for the account ");
	int pin1=sc.nextInt();
	serviceobj.showBalance(accno2, pin1);
	
			
				
			/*	if(c!=null)
					System.out.println(c);
			else{
					try{
						throw new CustomerNotFound();
					} catch(CustomerNotFound e){
						e.printStackTrace();
						
					}
				}*/
	
			
			
			break;
		case 4:
			Customer custobj4=new Customer();
			System.out.println("enter the account number");
			long accno3=sc.nextLong();
			System.out.println("enter the pin for the account");
			int pin2=sc.nextInt();
			System.out.println("enter the amount to be deposited");
			float depositamt=sc.nextFloat();
		Customer c4=	serviceobj.deposit(depositamt, accno3, pin2);
			
			break;
		case 5:
			Customer custobj5=new Customer();
			System.out.println("enter the account number");
			long accno4=sc.nextLong();
			System.out.println("enter the pin for the account");
			int pin3=sc.nextInt();
			System.out.println("enter the amount to be withdrawed");
			float withdrawamt=sc.nextFloat();
			serviceobj.withdraw(withdrawamt, accno4, pin3);
			break;
		case 6:
			Customer custobj6=new Customer();
				System.out.println("Enter your account number");
				long accno5=sc.nextLong();
				System.out.println("enter your account pin");
				int pin4=sc.nextInt();
				System.out.println("enter the accno to be transferred");
				long taccno=sc.nextLong();
				System.out.println("enter the amount to be transferred");
				float transferamt=sc.nextFloat();
				Customer c0=serviceobj.fundTransfer(accno5, pin4,  taccno, transferamt);
				/*System.out.println("The amount in your account after transferring is:"+ c1.getBalance());
				if(c1!=null) {
					System.out.println("The amount in your account after transferring is:"+ c1.getBalance());
				}*/
				/*if(c1!=null) {
					
				}else {
					try{
						throw new CustomerNotFound();
					} catch(CustomerNotFound e){
						e.printStackTrace();
						
					}
				}
					*/
				
			break;
		case 7:
			Customer custobj7=new Customer();
System.out.println("enter account number and pin to print transactions");
			
			System.out.println("enter your account number");
			long accno6 = sc.nextLong();
			
			System.out.println("enter your pin");
			int pin6 = sc.nextInt();
			Customer c6=serviceobj.printTransactions(custobj7);
		
			break;
		case 8:
			System.exit(0);
			break;
		 default:
			break;
			

	
	}
}
	}
}